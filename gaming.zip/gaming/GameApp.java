package com.gaming;
import java.util.*;
public class GameApp {
	public static void main(String[] args) {
		GameState gameState = new GameState(
                5,
                Arrays.asList("First Kill", "Treasure Hunter", "Level Master"),
                Arrays.asList("Sword", "Shield", "Health Potion")
        );
        GameStorage.saveGame(gameState, "game.save");
        GameState loadedGame = GameStorage.loadGame("game.save");
        System.out.println("\nLoaded Game State:");
        loadedGame.displayGameState();
	}
}