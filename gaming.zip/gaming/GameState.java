package com.gaming;

import java.io.Serializable;
import java.util.*;
public class GameState implements Serializable{
	private static final long serialVersionUID = 1L;
	private int level;
    private List<String> achievements;
    private List<String> inventory;
    public GameState(int level, List<String> achievements, List<String> inventory) {
        this.level = level;
        this.achievements = achievements;
        this.inventory = inventory;
    }
    public void displayGameState() {
        System.out.println("Game Level     : " + level);
        System.out.println("Achievements   : " + achievements);
        System.out.println("Inventory      : " + inventory);
    }
}