package com.gaming;
import java.io.*;
public class GameStorage {
	 public static void saveGame(GameState gameState, String fileName) {
	        try {
	            ObjectOutputStream oos =
	                    new ObjectOutputStream(new FileOutputStream(fileName));
	            oos.writeObject(gameState);
	            oos.close();
	            System.out.println("Game progress saved successfully.");
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	    public static GameState loadGame(String fileName) {
	        GameState gameState = null;
	        try {
	            ObjectInputStream ois =
	                    new ObjectInputStream(new FileInputStream(fileName));
	            gameState = (GameState) ois.readObject();
	            ois.close();
	            System.out.println("Game progress loaded successfully.");
	        } catch (IOException | ClassNotFoundException e) {
	            e.printStackTrace();
	        }
	        return gameState;
	    }
}