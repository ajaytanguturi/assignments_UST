this repository is all about the student management system where all the required student data will be available here.
