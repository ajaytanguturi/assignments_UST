package com.serialization;

public class BankApp {

	public static void main(String[] args) {
		try {
            Customer c1 = new Customer(101, "Ajay", "1234567890", "4321");
            SecureBankStorage.saveCustomer(c1, "customer.sec");
            Customer retrieved = SecureBankStorage.loadCustomer("customer.sec");
            System.out.println("\nDecrypted Customer Data:");
            retrieved.display();

        } catch (Exception e) {
            e.printStackTrace();
        }
	}

}
