package com.serialization;
import java.io.*;
public class SecureBankStorage {
	public static void saveCustomer(Customer customer, String fileName) throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(bos);
        oos.writeObject(customer);
        oos.close();

        byte[] encryptedData = EncryptionUtil.encrypt(bos.toByteArray());
        FileOutputStream fos = new FileOutputStream(fileName);
        fos.write(encryptedData);
        fos.close();
        System.out.println("Customer data securely saved.");
    }
    public static Customer loadCustomer(String fileName) throws Exception {
        FileInputStream fis = new FileInputStream(fileName);
        byte[] encryptedData = fis.readAllBytes();
        fis.close();
        byte[] decryptedData = EncryptionUtil.decrypt(encryptedData);
        ObjectInputStream ois = new ObjectInputStream(
                new ByteArrayInputStream(decryptedData));
        Customer customer = (Customer) ois.readObject();
        ois.close();
        return customer;
    }
}