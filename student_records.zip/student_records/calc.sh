echo " enter 1st number"
read num1
echo " enter 2nd number"
read num2
sum=$((num1+num2))
difference=$((num1-num2)) 
prod=$((num1*num2))
div=$((num1/num2))

echo "sum is : $sum"
echo "diff is : $diff"
echo "product is : $prod"
echo "quotient is : $div"

